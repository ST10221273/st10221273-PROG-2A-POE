﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeSystem
{
    /// <summary>
    /// Interaction logic for FilterRecipeWindow.xaml
    /// </summary>
    public partial class FilterRecipeWindow : Window
    {
        public List<Recipe> Recipes { get; set; }

        public FilterRecipeWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            Recipes = recipes;
            PopulateFoodGroups();
        }

        private void PopulateFoodGroups()
        {
            var foodGroups = Recipes
                .SelectMany(recipe => recipe.Ingredients)
                .Select(ingredient => ingredient.FoodGroup)
                .Distinct()
                .ToList();
            cmbFoodGroups.ItemsSource = foodGroups;
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            List<Recipe> filteredRecipes;
            if (!string.IsNullOrEmpty(txtIngredient.Text))
            {
                filteredRecipes = Recipes.Where(recipe => recipe.Ingredients.Any(ing => ing.Name.Contains(txtIngredient.Text))).ToList();
            }
            else
            {
                var selectedFoodGroup = cmbFoodGroups.SelectedItem?.ToString();
                filteredRecipes = Recipes.Where(recipe => recipe.Ingredients.Any(ing => ing.FoodGroup == selectedFoodGroup)).ToList();
            }

            lstFilteredRecipes.ItemsSource = filteredRecipes;
            lstFilteredRecipes.DisplayMemberPath = "Name";
        }
    }
}
