﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Text;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace RecipeSystem
{
    public partial class IngredientWindow : Window
    {
        public Ingredient Ingredient { get; private set; }

        public IngredientWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            double quantity;
            int calories;
            if (double.TryParse(txtQuantity.Text, out quantity) && quantity > 0 &&
                int.TryParse(txtCalories.Text, out calories) && calories > 0)
            {
                Ingredient = new Ingredient(txtName.Text, quantity, txtUnit.Text, calories, txtFoodGroup.Text);
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter valid positive numbers for quantity and calories.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}


