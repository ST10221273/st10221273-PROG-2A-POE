﻿using System.Windows;
using System.Windows.Controls;

namespace RecipeSystem
{
    public partial class RateApplicationWindow : Window
    {
        public int Rating { get; private set; }

        public RateApplicationWindow()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            StackPanel stackPanel = LogicalTreeHelper.GetChildren(this)
                                    .OfType<StackPanel>()
                                    .FirstOrDefault();

            if (stackPanel != null)
            {
                var radioButtons = stackPanel.Children.OfType<RadioButton>();

                if (radioButtons.Any())
                {
                    foreach (var radioButton in radioButtons)
                    {
                        if (radioButton.IsChecked == true)
                        {
                            Rating = int.Parse(radioButton.Content.ToString());
                            break;
                        }
                    }

                    if (Rating == 0)
                    {
                        MessageBox.Show("Please select a rating.", "Rating Required", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else
                    {
                        MessageBox.Show($"Thank you for rating the application {Rating} star(s)!", "Rating Submitted", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.DialogResult = true;
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Feature under construction.", "Loading.....", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Thank you for your rating.", "Success", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}