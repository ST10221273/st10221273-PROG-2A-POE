﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeSystem
{
    public partial class SelectRecipeWindow : Window
    {
        public Recipe SelectedRecipe { get; private set; }

        public SelectRecipeWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            lstRecipes.ItemsSource = recipes;
            lstRecipes.DisplayMemberPath = "Name";
        }

        private void btnSelect_Click(object sender, RoutedEventArgs e)
        {
            if (lstRecipes.SelectedItem != null)
            {
                SelectedRecipe = (Recipe)lstRecipes.SelectedItem;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Please select a recipe.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
